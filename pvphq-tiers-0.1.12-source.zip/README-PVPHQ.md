# PvPHQ Tiers 0.1.2 — Minecraft 1.21.11

Unofficial client-side PvPHQ adaptation of **Tiers 0.8.4**, originally by Flavio6561.
Based on upstream commit `abce7e1` from <https://github.com/PvPTiers/Tiers>, branch `1.21.11`.
The original GPL-3.0 license and author credit are retained. This is not an official PvPHQ release.

## Install

1. Use Minecraft **1.21.11**, **Java 21+**, and Fabric Loader **0.19.5+**.
2. Install Fabric API for 1.21.11.
3. Remove the original `tiers` mod from this instance, then put `pvphq-tiers-0.1.2+1.21.11.jar` in its `mods` folder. The fork intentionally refuses to load beside the original because both modify the same displays and command.
4. Mod Menu is optional; configuration is also available through `/tiers -config`.

## Retained controls and features

- Tier labels on nametags, Tab list, chat, and the original text-display hooks.
- `/tiers <name>` player search with skin, current and peak tiers, refresh buttons, and NameMC link.
- `/tiers` toggles the mod; `/tiers -config`, `-toggle`, `-clear`, `-status`, `-help`, and `-debug` retain their original roles.
- **Y** detects the kit, **H** opens the nearest player's profile, **U/I** cycle the left/right displayed kit. Keys are rebindable.
- Automatic kit detection, selected/adaptive-highest/highest display modes, left/right placement, icon/tab/chat toggles, and adaptive separator colors.
- Classic, PvPTiers-style, and MCTiers-style icon/color presets, resource-pack customization, preview switching, and persistent settings.
- Separate `config/PvPHQTiers.json` and `cache/pvphq-tiers` folders.

## PvPHQ additions and differences

All 11 PvPHQ kits are selectable: Sword, Axe, Mace, Spear, UHC, NethPot, Pot, SMP, DiaSMP, Vanilla, and Cart. Additional kits reuse suitable existing icon artwork; Spear uses the trident glyph.

The mod reads `https://pvphq.com/api/v1/players/<uuid>`. It supports HT/MT/LT tiers, peak tiers, TR and peak-TR tooltips, inactivity, and placement progress. Unranked placements appear in search results but never masquerade as ranked nametags. Legacy Cart and Vanilla identifiers are normalized.

Overall **points** come from PvPHQ. The player endpoint does **not** supply global leaderboard position or the date a tier was attained; those values are not invented. The tooltip instead shows the last-played date. Country is shown only when PvPHQ marks it public, with closest server in the tooltip. The inherited config sample is marked **demo** and does not represent live PvPHQ rankings.

Requests are asynchronous, spaced at least 300 ms apart, and back off when the service returns HTTP 429. The original in-memory cache, explicit refresh, and recovery behavior are retained. The mod also uses the original Minecraft-name lookup and skin services; no login token is required by this fork.

## Build

With Java 21 installed:

```powershell
.\gradlew.bat build
```

On macOS/Linux: `sh gradlew build`.

`build/libs` contains the mod and sources JARs. `check` runs the standalone PvPHQ parser regression checks through `verifyPvPHQ`. The checked-in fixture is a public API snapshot captured on 2026-11-04; tests never need to query the live service.

The optional `-PlocalDependencyRepo=<path>` flag supports an offline Maven directory containing a `modules.txt` list of `group:artifact` coordinates. Normal builds do not need it.

## Validation limits

See the delivered `BUILD-REPORT.txt` for checks actually completed. A successful compilation and parser test do not establish compatibility with every server, shader, or other nametag/chat mod. PvPHQ may change its endpoint or access requirements.

## Logo update (0.1.2)

The mod icon, resource-pack icon, configuration screen, and player-profile screen now use the original PvPHQ logo from https://pvphq.com/assets/pvphq-logo.png. The image is included unchanged; the mod remains unofficial.

PvPHQ kit icons: all 11 kits have distinct glyphs in Classic, PvPTiers-style, and MCTiers-style presets. Spear, DiaSMP, and Cart use matching trident, diamond armor, and minecart artwork in each preset.
