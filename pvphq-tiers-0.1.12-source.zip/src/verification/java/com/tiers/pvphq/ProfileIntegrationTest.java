package com.tiers.pvphq;

import com.tiers.misc.Mode;
import com.tiers.profile.Status;
import com.tiers.profile.types.PvPTiersProfile;
import com.tiers.textures.ColorControl;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public final class ProfileIntegrationTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        String json;
        try (var input = ProfileIntegrationTest.class.getResourceAsStream("/pvphq-player.json")) {
            json = new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
        var profile = new PvPTiersProfile(json);
        check(profile.status == Status.READY, "Profile ready");
        check(profile.gameModes.size() == 11, "All 11 selectable kits");
        check(profile.displayedOverall.getString().equals("106"), "Actual points, no fictional rank");
        check(profile.displayedRegion.getString().equals("US"), "Country display");
        var sword = profile.getGameMode(Mode.PVPTIERS_SWORD);
        check(sword.displayedTier.getString().equals("HT3"), "Rendered sword label");
        check(sword.tierTooltip.getString().contains("TR: 719"), "TR tooltip");
        check(!sword.tierTooltip.getString().contains("Attained"), "Do not invent attained date");
        var pot = profile.getGameMode(Mode.PVPTIERS_POT);
        check(pot.hasPeak && pot.peakTierTooltip.getString().contains("378"), "Peak TR on same tier");
        var spear = profile.getGameMode(Mode.PVPTIERS_SPEAR);
        check(spear.placement && spear.status == Status.NOT_EXISTING, "Placements excluded from tags");
        check(spear.displayedTier.getString().equals("4/10"), "Placement progress rendered");
        check(profile.getGameMode(Mode.PVPTIERS_AXE).status == Status.NOT_EXISTING, "Missing kit");
        check(profile.highest != null && profile.highest.displayedTier.getString().equals("HT3"), "Highest mode");
        final boolean[] called = {false};
        profile.setOnUpdate(() -> called[0] = true);
        check(called[0], "Callback registered after response must still run");
        profile.parseJson(profile.originalJson);
        check(profile.getGameMode(Mode.PVPTIERS_POT).hasPeak, "Restyling preserves peak data");
        var middle = new PvPTiersProfile("""
            {"name":"Example","ranked":[
             {"gametype":"sword","tier":"MT3","peakTier":"HT3","tierProgress":20,"hasTr":true},
             {"gametype":"axe","tier":"LT3"}]}
            """);
        check(middle.highest.gamemode == Mode.PVPTIERS_SWORD, "Middle tier sorts above lower tier");
        check(middle.highest.displayedTier.getString().equals("MT3"), "Middle tier text survives rendering");
        int defaultMt3 = ColorControl.getColor("mt3");
        ColorControl.setTierOverrides(Map.of("mt3", 0xC095FF, "ht3", 0x6FD6FF));
        middle.parseJson(middle.originalJson);
        var recolored = middle.getGameMode(Mode.PVPTIERS_SWORD);
        check(recolored.displayedTier.getStyle().getColor().getRgb() == 0xC095FF, "Custom current tier color");
        check(recolored.displayedPeakTier.getStyle().getColor().getRgb() == 0x6FD6FF, "Custom peak tier color");
        check(recolored.tierTooltip.getStyle().getColor().getRgb() == 0xC095FF, "Custom tier tooltip color");
        ColorControl.setTierOverrides(null);
        middle.parseJson(middle.originalJson);
        check(recolored.displayedTier.getStyle().getColor().getRgb() == defaultMt3, "Reset restores palette color");
        System.out.println("PvPHQ Minecraft profile integration: " + checks + " checks passed.");
    }
}
