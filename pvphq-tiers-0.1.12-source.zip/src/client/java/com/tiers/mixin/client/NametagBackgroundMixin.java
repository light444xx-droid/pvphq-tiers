package com.tiers.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.tiers.misc.NametagBackground;
import net.minecraft.client.render.command.LabelCommandRenderer;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LabelCommandRenderer.Commands.class)
abstract class NametagBackgroundMixin {
    @ModifyExpressionValue(method = "add", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/option/GameOptions;getTextBackgroundOpacity(F)F"))
    private float tiers$clearTierLabelBackground(float opacity, @Local(argsOnly = true) Text label) {
        return NametagBackground.isTransparent(label) ? 0 : opacity;
    }
}
