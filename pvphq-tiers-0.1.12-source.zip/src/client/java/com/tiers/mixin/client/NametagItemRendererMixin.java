package com.tiers.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.tiers.TiersClient;
import com.tiers.misc.Mode;
import com.tiers.profile.PlayerProfile;
import com.tiers.misc.NametagBackground;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Renders the selected PvPHQ kit as a live Minecraft item next to the name. */
@Mixin(PlayerEntityRenderer.class)
public abstract class NametagItemRendererMixin {
    @WrapOperation(
            method = "renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At(value = "INVOKE", ordinal = 1, target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitLabel(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/math/Vec3d;ILnet/minecraft/text/Text;ZIDLnet/minecraft/client/render/state/CameraRenderState;)V"))
    private void tiers$renderKitItem(OrderedRenderCommandQueue commands, MatrixStack matrices, Vec3d anchor,
                                     int textY, Text label, boolean seeThrough, int light,
                                     double squaredDistance, CameraRenderState camera, Operation<Void> original,
                                     @Local(argsOnly = true) PlayerEntityRenderState state) {
        MinecraftClient client = MinecraftClient.getInstance();
        Entity entity = client.world == null ? null : client.world.getEntityById(state.id);
        PlayerProfile profile = entity == null ? null : TiersClient.readyPlayerProfiles.get(entity.getNameForScoreboard());
        Mode mode = profile == null ? null : profile.getDisplayedPvPHQMode();
        if (anchor == null || mode == null) {
            original.call(commands, matrices, anchor, textY, label, seeThrough, light, squaredDistance, camera);
            return;
        }

        NametagBackground.withoutBackground(label,
                () -> original.call(commands, matrices, anchor, textY, label, seeThrough, light, squaredDistance, camera));
        if (!TiersClient.toggleIcons)
            return;

        ItemRenderState itemState = new ItemRenderState();
        ItemModelManager modelManager = client.getItemModelManager();
        modelManager.updateForNonLivingEntity(itemState, mode.createDisplayStack(), ItemDisplayContext.GUI, entity);
        if (itemState.isEmpty())
            return;

        Box bounds = itemState.getModelBoundingBox();
        double extent = Math.max(bounds.getLengthX(), bounds.getLengthY());
        boolean hasBounds = Double.isFinite(extent) && extent > 0;
        float scale = hasBounds ? (float) (0.20 / extent) : 0.20F;
        Vec3d center = hasBounds ? bounds.getCenter() : Vec3d.ZERO;
        float iconHalfWidth = hasBounds ? (float) (bounds.getLengthX() * scale / 2) : 0.10F;
        float direction = TiersClient.positionPvPTiers == TiersClient.DisplayStatus.LEFT ? -1.0F : 1.0F;
        float textHalfWidth = client.textRenderer.getWidth(label) * 0.025F / 2;

        // Match LabelCommandRenderer.Commands.add, using the matrix and offset
        // of the name call itself (including vanilla's optional scoreboard row).
        matrices.push();
        matrices.translate(anchor.x, anchor.y + 0.5, anchor.z);
        matrices.multiply(camera.orientation);
        matrices.translate(direction * (textHalfWidth + 0.05F + iconHalfWidth), -(textY + 4) * 0.025F, 0.01F);
        matrices.scale(scale, scale, scale);
        matrices.translate(-center.x, -center.y, -center.z);
        itemState.render(matrices, commands, light, OverlayTexture.DEFAULT_UV, 0);
        matrices.pop();
    }
}
