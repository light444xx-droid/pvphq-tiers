package com.tiers.profile.types;

import com.google.gson.JsonParser;
import com.tiers.misc.Mode;
import com.tiers.profile.GameMode;
import com.tiers.profile.Status;
import com.tiers.pvphq.PvPHQData;
import com.tiers.textures.Icons;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.Locale;

/** Upstream class name retained; live tier data is exclusively PvPHQ. */
public class PvPTiersProfile extends SuperProfile {
    public static final Identifier PVPTIERS_IMAGE = Identifier.of("tiers", "textures/pvphq_logo.png");
    public PvPTiersProfile(String apiUrl, String uuid, String extra) {
        super(); addGamemodes(); buildRequest(apiUrl, uuid, extra);
    }
    public PvPTiersProfile(String json) {
        super(); addGamemodes(); parseJson(json);
    }
    private void addGamemodes() {
        gameModes.add(new GameMode(Mode.PVPTIERS_CRYSTAL, "vanilla"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SWORD, "sword"));
        gameModes.add(new GameMode(Mode.PVPTIERS_UHC, "uhc"));
        gameModes.add(new GameMode(Mode.PVPTIERS_POT, "pot"));
        gameModes.add(new GameMode(Mode.PVPTIERS_NETH_POT, "netherite_pot"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SMP, "smp"));
        gameModes.add(new GameMode(Mode.PVPTIERS_AXE, "axe"));
        gameModes.add(new GameMode(Mode.PVPTIERS_MACE, "mace"));
        gameModes.add(new GameMode(Mode.PVPTIERS_SPEAR, "spear_mace"));
        gameModes.add(new GameMode(Mode.PVPTIERS_DIAMOND_SMP, "diamond_smp"));
        gameModes.add(new GameMode(Mode.PVPTIERS_CART, "cart"));
    }
    @Override public void parseJson(String json) {
        // The bundled illustrative preview is not a live player ranking.
        if (apiUrl == null && JsonParser.parseString(json).getAsJsonObject().has("rankings")) {
            var preview = JsonParser.parseString(json).getAsJsonObject();
            var rankings = preview.getAsJsonObject("rankings");
            if (rankings.has("crystal")) rankings.add("vanilla", rankings.get("crystal"));
            if (rankings.has("neth_pot")) rankings.add("netherite_pot", rankings.get("neth_pot"));
            super.parseJson(preview.toString()); return;
        }
        PvPHQData data = PvPHQData.parse(json);
        for (GameMode mode : gameModes) {
            var kit = data.kits().get(mode.parsingName);
            if (kit == null) { mode.status = Status.NOT_EXISTING; mode.hasPeak = false; }
            else mode.parsePvPHQ(kit);
        }
        highest = getHighestMode();
        String country = data.country().replace('_', ' ');
        String shortCountry = "--";
        for (String iso : Locale.getISOCountries()) {
            if (Locale.of("", iso).getDisplayCountry(Locale.ENGLISH).equalsIgnoreCase(country)) {
                shortCountry = iso; break;
            }
        }
        displayedRegion = Icons.colorText(shortCountry, "region");
        regionTooltip = Text.literal((country.isEmpty() ? "Country not shared" : country)
                + (data.region().isEmpty() ? "" : "\nClosest server: " + data.region().replace('_',' ')));
        displayedOverall = Icons.colorText(Integer.toString(data.points()), "overall");
        overallTooltip = Text.literal("PvPHQ overall points: " + data.points()
                + "\nGlobal position is not supplied by the player endpoint.");
        drawn = false; originalJson = json; status = Status.READY;
        if (onUpdate != null) onUpdate.run();
    }
}
