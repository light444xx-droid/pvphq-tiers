package com.tiers.screens;

import com.tiers.TiersClient;
import com.tiers.misc.ConfigManager;
import com.tiers.profile.PlayerProfile;
import com.tiers.textures.ColorControl;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class TierColorsScreen extends Screen {
    private static final String[] PREFIXES = {"ht", "mt", "lt"};
    private static final int[] PALETTE = {
            0xFF6B7A, 0xFFAA60, 0xFFD76A, 0x68D8B5, 0x6FD6FF, 0x809BFF, 0xC095FF, 0xFFA6DF, 0xEEEEEE
    };
    private final Screen parent;
    private final Map<String, ButtonWidget> tierButtons = new HashMap<>();
    private String selected = "mt4";
    private TextFieldWidget hex;
    private ButtonWidget apply;
    private int top;

    TierColorsScreen(Screen parent) {
        super(Text.literal("Tier Colors"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = width / 2;
        top = Math.max(4, (height - 176) / 2);
        tierButtons.clear();

        for (int row = 0; row < PREFIXES.length; row++) {
            for (int column = 0; column < 5; column++) {
                String tier = PREFIXES[row] + (column + 1);
                ButtonWidget button = addDrawableChild(ButtonWidget.builder(tierText(tier, ColorControl.getColor(tier)),
                        pressed -> selectTier(tier))
                        .dimensions(center - 108 + column * 44, top + 16 + row * 21, 40, 20).build());
                tierButtons.put(tier, button);
            }
        }

        for (int index = 0; index < PALETTE.length; index++) {
            int rgb = PALETTE[index];
            String value = toHex(rgb);
            addDrawableChild(ButtonWidget.builder(Text.literal("■").styled(style -> style.withColor(rgb)),
                            button -> hex.setText(value))
                    .dimensions(center - 98 + index * 22, top + 84, 20, 20)
                    .tooltip(Tooltip.of(Text.literal(value))).build());
        }

        hex = addDrawableChild(new TextFieldWidget(textRenderer, center - 108, top + 112, 76, 20, Text.literal("Hex color")));
        hex.setMaxLength(7);
        apply = addDrawableChild(ButtonWidget.builder(Text.literal("Apply"), button -> {
            Integer rgb = readHex();
            if (rgb != null)
                saveColor(rgb);
        }).dimensions(center - 27, top + 112, 55, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset Tier"), button -> saveColor(null))
                .dimensions(center + 33, top + 112, 75, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(center - 50, top + 152, 100, 20).build());

        hex.setChangedListener(value -> apply.active = readHex() != null);
        selectTier(selected);
    }

    private void selectTier(String tier) {
        selected = tier;
        hex.setText(toHex(ColorControl.getColor(tier)));
        tierButtons.forEach((key, button) -> button.setMessage(tierText(key, ColorControl.getColor(key))));
    }

    private void saveColor(Integer rgb) {
        Map<String, Integer> overrides = new HashMap<>(ColorControl.getTierOverrides());
        if (rgb == null)
            overrides.remove(selected);
        else
            overrides.put(selected, rgb);
        ColorControl.setTierOverrides(overrides);

        Set<PlayerProfile> profiles = new LinkedHashSet<>(TiersClient.playerProfiles);
        profiles.addAll(TiersClient.readyPlayerProfiles.values());
        if (ConfigScreen.ownProfile != null)
            profiles.add(ConfigScreen.ownProfile);
        if (ConfigScreen.defaultProfile != null)
            profiles.add(ConfigScreen.defaultProfile);
        TiersClient.restyleAllTexts(new ArrayList<>(profiles));
        ConfigManager.saveConfig();
        selectTier(selected);
    }

    private Integer readHex() {
        String value = hex.getText();
        if (value.startsWith("#"))
            value = value.substring(1);
        return value.matches("[0-9a-fA-F]{6}") ? Integer.parseInt(value, 16) : null;
    }

    private static String toHex(int rgb) {
        return String.format(Locale.ROOT, "#%06X", rgb & 0xFFFFFF);
    }

    private static Text tierText(String tier, int rgb) {
        return Text.literal(tier.toUpperCase(Locale.ROOT)).styled(style -> style.withColor(rgb));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, top + 2, 0xFFFFFFFF);
        Integer rgb = readHex();
        Text preview = rgb == null ? Text.literal("Enter a six-digit hex color")
                : Text.literal("Preview: ").append(tierText(selected, rgb));
        context.drawCenteredTextWithShadow(textRenderer, preview, width / 2, top + 137, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
