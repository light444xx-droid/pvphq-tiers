package com.tiers.misc;

import com.tiers.textures.Icons;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potions;
import net.minecraft.util.Colors;
import net.minecraft.util.Identifier;

import java.util.Arrays;
import java.util.Locale;

public enum Mode {
    MCTIERS_VANILLA(Category.MCTIERS, "\uF000", "Vanilla"),
    MCTIERS_UHC(Category.MCTIERS, "\uF001", "UHC"),
    MCTIERS_POT(Category.MCTIERS, "\uF002", "Pot"),
    MCTIERS_NETH_OP(Category.MCTIERS, "\uF003", "Neth Op"),
    MCTIERS_SMP(Category.MCTIERS, "\uF004", "Smp"),
    MCTIERS_SWORD(Category.MCTIERS, "\uF005", "Sword"),
    MCTIERS_AXE(Category.MCTIERS, "\uF006", "Axe"),
    MCTIERS_MACE(Category.MCTIERS, "\uF007", "Mace"),

    PVPTIERS_CRYSTAL(Category.PVPTIERS, "\uF000", "Vanilla"),
    PVPTIERS_SWORD(Category.PVPTIERS, "\uF005", "Sword"),
    PVPTIERS_UHC(Category.PVPTIERS, "\uF001", "UHC"),
    PVPTIERS_POT(Category.PVPTIERS, "\uF002", "Pot"),
    PVPTIERS_NETH_POT(Category.PVPTIERS, "\uF003", "Neth Pot"),
    PVPTIERS_SMP(Category.PVPTIERS, "\uF004", "Smp"),
    PVPTIERS_AXE(Category.PVPTIERS, "\uF006", "Axe"),
    PVPTIERS_MACE(Category.PVPTIERS, "\uF007", "Mace"),

    PVPTIERS_SPEAR(Category.PVPTIERS, "\uF008", "Spear"),
    PVPTIERS_DIAMOND_SMP(Category.PVPTIERS, "\uF009", "DiaSMP"),
    PVPTIERS_CART(Category.PVPTIERS, "\uF00A", "Cart"),

    SUBTIERS_MINECART(Category.SUBTIERS, "\uF000", "Minecart"),
    SUBTIERS_DIAMOND_VANILLA(Category.SUBTIERS, "\uF001", "Diamond Vanilla"),
    SUBTIERS_DEBUFF(Category.SUBTIERS, "\uF002", "DeBuff"),
    SUBTIERS_ELYTRA(Category.SUBTIERS, "\uF003", "Elytra"),
    SUBTIERS_SPEED(Category.SUBTIERS, "\uF004", "Speed"),
    SUBTIERS_CREEPER(Category.SUBTIERS, "\uF005", "Creeper"),
    SUBTIERS_MANHUNT(Category.SUBTIERS, "\uF006", "Manhunt"),
    SUBTIERS_DIAMOND_SMP(Category.SUBTIERS, "\uF007", "Diamond Smp"),
    SUBTIERS_BOW(Category.SUBTIERS, "\uF008", "Bow"),
    SUBTIERS_BED(Category.SUBTIERS, "\uF009", "Bed"),
    SUBTIERS_OG_VANILLA(Category.SUBTIERS, "\uF00A", "OG Vanilla"),
    SUBTIERS_TRIDENT(Category.SUBTIERS, "\uF00B", "Trident");

    private final Category category;
    private final String unicode;
    private final String label;

    Mode(Category category, String unicode, String label) {
        this.category = category;
        this.unicode = unicode;
        this.label = label;
    }

    public enum Category {
        MCTIERS,
        PVPTIERS,
        SUBTIERS
    }

    public Text getIcon() {
        Identifier identifier = switch (category) {
            case MCTIERS -> Icons.identifierMCTiers;
            case PVPTIERS -> Icons.identifierPvPTiers;
            case SUBTIERS -> Icons.identifierSubtiers;
        };
        return Text.literal(unicode).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(identifier)).withColor(Colors.WHITE));
    }

    public Text getIconTag() {
        Identifier identifier = switch (category) {
            case MCTIERS -> Icons.identifierMCTiersTags;
            case PVPTIERS -> Icons.identifierPvPTiersTags;
            case SUBTIERS -> Icons.identifierSubtiersTags;
        };
        return Text.literal(unicode).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(identifier)).withColor(Colors.WHITE));
    }

    public Text getTextLabel() {
        return Icons.colorText(label, name().toLowerCase(Locale.ROOT));
    }

    /**
     * The actual vanilla item used above a player's nametag.  Rendering an
     * ItemStack (instead of a texture in this mod) deliberately lets the
     * currently enabled resource pack provide the model and animation.
     */
    public ItemStack createDisplayStack() {
        if (this == PVPTIERS_POT)
            return PotionContentsComponent.createStack(Items.SPLASH_POTION, Potions.HEALING);

        return new ItemStack(switch (this) {
            case PVPTIERS_CRYSTAL -> Items.END_CRYSTAL;
            case MCTIERS_VANILLA, SUBTIERS_DIAMOND_VANILLA, SUBTIERS_OG_VANILLA -> Items.DIAMOND_SWORD;
            case PVPTIERS_SWORD, MCTIERS_SWORD -> Items.DIAMOND_SWORD;
            case PVPTIERS_UHC -> Items.LAVA_BUCKET;
            case MCTIERS_UHC, SUBTIERS_BOW -> Items.BOW;
            case PVPTIERS_POT, MCTIERS_POT -> Items.SPLASH_POTION;
            case PVPTIERS_NETH_POT -> Items.NETHERITE_HELMET;
            case MCTIERS_NETH_OP -> Items.NETHERITE_SWORD;
            case PVPTIERS_SMP -> Items.ENDER_PEARL;
            case MCTIERS_SMP, SUBTIERS_DIAMOND_SMP -> Items.TOTEM_OF_UNDYING;
            case PVPTIERS_AXE, MCTIERS_AXE -> Items.DIAMOND_AXE;
            case PVPTIERS_MACE, MCTIERS_MACE -> Items.MACE;
            case PVPTIERS_SPEAR -> Items.DIAMOND_SPEAR;
            case PVPTIERS_DIAMOND_SMP -> Items.DIAMOND_CHESTPLATE;
            case PVPTIERS_CART, SUBTIERS_MINECART -> Items.TNT_MINECART;
            case SUBTIERS_DEBUFF -> Items.SPLASH_POTION;
            case SUBTIERS_ELYTRA -> Items.ELYTRA;
            case SUBTIERS_SPEED -> Items.SUGAR;
            case SUBTIERS_CREEPER -> Items.CREEPER_SPAWN_EGG;
            case SUBTIERS_MANHUNT -> Items.COMPASS;
            case SUBTIERS_BED -> Items.RED_BED;
            case SUBTIERS_TRIDENT -> Items.TRIDENT;
        });
    }

    public static Mode[] getMCTiersValues() {
        return Arrays.stream(values()).filter(mode -> mode.toString().contains("MCTIERS")).toArray(Mode[]::new);
    }

    public static Mode[] getPvPTiersValues() {
        return Arrays.stream(values()).filter(mode -> mode.toString().contains("PVPTIERS")).toArray(Mode[]::new);
    }

    public static Mode[] getSubtiersValues() {
        return Arrays.stream(values()).filter(mode -> mode.toString().contains("SUBTIERS")).toArray(Mode[]::new);
    }
}
