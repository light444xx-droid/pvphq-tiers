package com.tiers.misc;

import net.minecraft.text.Text;

/** Limits the background override to the synchronous submission of a PvPHQ label. */
public final class NametagBackground {
    private static final ThreadLocal<Text> TRANSPARENT_LABEL = new ThreadLocal<>();

    private NametagBackground() {}

    public static void withoutBackground(Text label, Runnable submit) {
        Text previous = TRANSPARENT_LABEL.get();
        TRANSPARENT_LABEL.set(label);
        try {
            submit.run();
        } finally {
            if (previous == null)
                TRANSPARENT_LABEL.remove();
            else
                TRANSPARENT_LABEL.set(previous);
        }
    }

    public static boolean isTransparent(Text label) {
        return label != null && label == TRANSPARENT_LABEL.get();
    }
}
