package com.tiers.textures;

import com.google.gson.JsonObject;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

public class ColorControl {
    private static final HashMap<String, Integer> colors = new HashMap<>();
    private static volatile Map<String, Integer> tierOverrides = Map.of();

    public static void updateColors(JsonObject jsonObject) {
        colors.clear();
        jsonObject.keySet().forEach(key -> colors.put(key, Integer.parseUnsignedInt(jsonObject.get(key).getAsString().replace("#", ""), 16)));

        Icons.GLOBE = Text.literal("\uF000").setStyle(Style.EMPTY.withColor(getColorMinecraftStandard("region")).withFont(new StyleSpriteSource.Font(Identifier.of("minecraft", "misc"))));
        Icons.OVERALL = Text.literal("\uF001").setStyle(Style.EMPTY.withColor(getColorMinecraftStandard("overall")).withFont(new StyleSpriteSource.Font(Identifier.of("minecraft", "misc"))));
    }

    public static int getColor(String colorName) {
        Integer override = tierOverrides.get(colorName);
        return override == null ? getDefaultColor(colorName) : override;
    }

    public static int getDefaultColor(String colorName) {
        return colors.getOrDefault(colorName, 0xaaaaaa);
    }

    public static Map<String, Integer> getTierOverrides() {
        return tierOverrides;
    }

    public static void setTierOverrides(Map<String, Integer> overrides) {
        Map<String, Integer> valid = new HashMap<>();
        if (overrides != null) {
            overrides.forEach((tier, rgb) -> {
                if (tier != null && tier.matches("[hml]t[1-5]") && rgb != null && rgb >= 0 && rgb <= 0xFFFFFF)
                    valid.put(tier, rgb);
            });
        }
        tierOverrides = Map.copyOf(valid);
    }

    public static int getColorMinecraftStandard(String colorName) {
        return 0xff000000 | (getColor(colorName) & 0x00ffffff);
    }
}
