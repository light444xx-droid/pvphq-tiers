package com.tiers.pvphq;

import java.nio.charset.StandardCharsets;

/** Runs without a game client; guards against silently showing incorrect rankings. */
public final class PvPHQDataTest {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        String fixture;
        try (var input = PvPHQDataTest.class.getResourceAsStream("/pvphq-player.json")) {
            fixture = new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
        var p = PvPHQData.parse(fixture);
        check(p.name().equals("Kylaz"), "Live-format player name");
        check(p.points() == 106, "Use actual overall points");
        check(p.kits().get("sword").tier().equals("HT3"), "Sword tier");
        check(p.kits().get("sword").tr() == 719, "TR is tierProgress, not rating");
        check(p.kits().get("pot").peakTr() == 378, "Peak TR");
        check(p.kits().get("spear_mace").unranked(), "Placement is not a tier");
        check(p.kits().get("spear_mace").placements() == 4, "Placement progress");
        check(p.kits().get("cart").inactive(), "Inactive survives alias normalization");
        check(!p.kits().containsKey("ht_cart"), "Canonical Cart kit");
        check(p.kits().get("netherite_pot").peakTier().equals("HT3"), "Peak tier");
        check(p.kits().size() == 9, "Absent kits are not invented");
        var edge = PvPHQData.parse("""
            {"name":"Example","country":"INDIA","countryVisible":false,"ranked":[
              {"gametype":"sword","tier":"MT3","peakTier":null,"tierProgress":42,"hasTr":true},
              {"gametype":"lt_cart","tier":"LT4"},
              {"gametype":"ht_cart","tier":"HT3"},
              {"gametype":"ht_vanilla","tier":"MT4"},
              {"gametype":"spear_mace","tier":"unknown"}
            ]}
            """);
        check(edge.country().isEmpty(), "Honor country privacy");
        check(edge.kits().get("sword").tier().equals("MT3"), "Do not flatten middle tiers");
        check(edge.kits().get("sword").peakTier().isEmpty(), "Do not invent unknown peak");
        check(edge.kits().get("cart").tier().equals("HT3"), "Deduplicate legacy aliases");
        check(edge.kits().get("vanilla").tier().equals("MT4"), "Vanilla alias");
        check(edge.kits().get("spear_mace").unranked(), "Unknown tier is not ranked");
        check(edge.points() == 0, "Missing overall data");
        check(PvPHQData.strengthOf("HT3") > PvPHQData.strengthOf("MT3"), "HT > MT");
        check(PvPHQData.strengthOf("MT3") > PvPHQData.strengthOf("LT3"), "MT > LT");
        check(PvPHQData.strengthOf("LT3") > PvPHQData.strengthOf("HT4"), "LT3 > HT4");
        check(PvPHQData.strengthOf("Unranked") == 0, "Unranked strength");
        for (String invalid : new String[]{"null", "{}", "<html>Unavailable</html>", "{\"name\":\"X\",\"ranked\":{}}"}) {
            boolean failed = false;
            try { PvPHQData.parse(invalid); } catch (RuntimeException expected) { failed = true; }
            check(failed, "Reject malformed/error payload");
        }
        System.out.println("PvPHQ parser: " + checks + " checks passed.");
    }
}
