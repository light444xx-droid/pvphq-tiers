package com.tiers.pvphq;

import com.google.gson.*;
import java.util.*;
import java.util.regex.Pattern;

/** PvPHQ wire-format parser, independent of Minecraft rendering. */
public record PvPHQData(String name, String country, String region, int points, Map<String, Kit> kits) {
    private static final Pattern TIER = Pattern.compile("[HML]T[1-5]");
    public record Kit(String id, String tier, String peakTier, int tr, int peakTr,
                      boolean hasTr, boolean inactive, boolean unranked,
                      int placements, int placementTarget, long lastPlayedAt) {
        public int strength() { return strengthOf(tier); }
    }
    public static String canonicalKit(String id) {
        return switch (id) {
            case "ht_cart", "lt_cart" -> "cart";
            case "ht_vanilla" -> "vanilla";
            default -> id;
        };
    }
    public static int strengthOf(String tier) {
        if (tier == null || !TIER.matcher(tier).matches()) return 0;
        return (6 - Character.digit(tier.charAt(2), 10)) * 3
                + (tier.charAt(0) == 'H' ? 2 : tier.charAt(0) == 'M' ? 1 : 0);
    }
    public static PvPHQData parse(String json) {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        if (!root.has("name") || !root.has("ranked") || !root.get("ranked").isJsonArray())
            throw new IllegalArgumentException("Missing PvPHQ player fields");
        Map<String, Kit> kits = new LinkedHashMap<>();
        for (JsonElement element : root.getAsJsonArray("ranked")) {
            JsonObject k = element.getAsJsonObject();
            String id = canonicalKit(string(k, "gametype", ""));
            if (id.isEmpty()) continue;
            String tier = string(k, "tier", "Unranked").toUpperCase(Locale.ROOT);
            boolean unranked = bool(k, "unranked", false) || !TIER.matcher(tier).matches();
            String peak = string(k, "peakTier", "").toUpperCase(Locale.ROOT);
            if (!TIER.matcher(peak).matches()) peak = "";
            Kit kit = new Kit(id, unranked ? "Unranked" : tier, peak,
                    integer(k, "tierProgress", 0), integer(k, "peakTr", 0),
                    bool(k, "hasTr", false), bool(k, "inactive", false), unranked,
                    integer(k, "placementGames", 0), integer(k, "placementTarget", 10),
                    number(k, "lastPlayedAt", 0));
            kits.merge(id, kit, (a,b) -> b.strength() > a.strength()
                    || b.strength() == a.strength() && b.lastPlayedAt() > a.lastPlayedAt() ? b : a);
        }
        int points = root.has("overall") && root.get("overall").isJsonObject()
                ? integer(root.getAsJsonObject("overall"), "points", 0) : 0;
        return new PvPHQData(string(root,"name",""),
                bool(root,"countryVisible",false) ? string(root,"country","") : "",
                string(root,"closestRegion",""), points, Collections.unmodifiableMap(kits));
    }
    private static String string(JsonObject o,String k,String fallback) {
        return !o.has(k) || o.get(k).isJsonNull() ? fallback : o.get(k).getAsString();
    }
    private static long number(JsonObject o,String k,long fallback) {
        return !o.has(k) || o.get(k).isJsonNull() ? fallback : o.get(k).getAsLong();
    }
    private static int integer(JsonObject o,String k,int fallback) { return (int)number(o,k,fallback); }
    private static boolean bool(JsonObject o,String k,boolean fallback) {
        return !o.has(k) || o.get(k).isJsonNull() ? fallback : o.get(k).getAsBoolean();
    }
}
